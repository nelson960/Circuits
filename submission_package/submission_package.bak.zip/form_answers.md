# Draft Form Answers

Use this as a working sheet for OpenReview/workshop form fields. Remove author-identifying details from any field visible to reviewers.

## One-Sentence Summary

This paper audits how a symbolic lookup role forms during training in a small transformer, tracing it through QK route geometry, causal subspaces, optimizer-update attribution, cross-seed address movement, and contextual write/readout structure.

## Contribution Summary

The contribution is not a new primitive method, but a controlled formation audit. A single retrieval role is followed from behavioral acquisition into low-rank QK route geometry, causal route/write tests, first-order attribution using actual AdamW parameter updates, cross-seed role/address dissociation, and a broader contextual write/readout value-code account.

## Reproducibility Statement

The anonymous supplement contains the training and benchmark configs, dataset/probe metadata, compact CSV tables for every main numerical claim, figure assets, environment metadata, and reproduction commands. It intentionally excludes large raw checkpoint sweeps; the submitted claims can be audited from compact derived artifacts and rerun from the included configs.

## Code/Data Availability

An anonymized repository or archive can be provided for review. The reviewer-visible package should not contain author names, personal GitHub usernames, personal website links, or local filesystem paths.

## Limitations

The task is synthetic and small. The QK route account is stronger than the write/readout account. The write side is causal and supported as a contextual high-rank value-code operation, but not derived as a closed-form static W_OV theorem. First-order update attribution is local and approximate as a scalar attribution. The AdamW-vs-SGD result is bounded to the tested seed-7 recipe and budget. Cross-seed role/address recurrence is shown in one task family, not as a general theorem.

## Ethics and Safety

This work studies transparency tools for small controlled transformers. It does not train or release a capability-advancing language model. The main risk is overgeneralization from a synthetic task; the paper explicitly bounds the claims.

## Double-Blind Statement

The submitted PDF and reviewer supplement are anonymized. Organizer-facing metadata is kept separate from reviewer-facing files.
